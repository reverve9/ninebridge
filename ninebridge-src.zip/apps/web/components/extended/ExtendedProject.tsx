'use client';

import React, { useState, useEffect } from 'react';
import { Project, GalleryItem } from '@/lib/types';
import { getPublishedProjects } from '@/lib/projects';

interface ExtendedProjectProps {
  selectedProjectId?: string | null;
}

const categoryColors: Record<string, { bg: string; text: string }> = {
  platform: { bg: 'bg-[#3071a5]', text: 'text-white' },
  marketing: { bg: 'bg-[#ef4444]', text: 'text-white' },
  contents: { bg: 'bg-[#eab308]', text: 'text-white' },
  etc: { bg: 'bg-[#6b7280]', text: 'text-white' },
};

const categoryLabels: Record<string, string> = {
  platform: '플랫폼',
  marketing: '마케팅',
  contents: '콘텐츠',
  etc: '기타',
};

export default function ExtendedProject({ selectedProjectId }: ExtendedProjectProps) {
  const [projects, setProjects] = useState<Project[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);
  const [isYoutubePlaying, setIsYoutubePlaying] = useState(false);
  const [currentGalleryIndex, setCurrentGalleryIndex] = useState(0);
  const [isHoveringMain, setIsHoveringMain] = useState(false);

  useEffect(() => {
    loadProjects();
  }, []);

  useEffect(() => {
    if (selectedProjectId && projects.length > 0) {
      const project = projects.find(p => p.id === selectedProjectId);
      setSelectedProject(project || null);
    } else {
      setSelectedProject(null);
    }
  }, [selectedProjectId, projects]);

  // 프로젝트 변경 시 상태 초기화
  useEffect(() => {
    setIsYoutubePlaying(false);
    if (selectedProject?.gallery) {
      const mainIndex = selectedProject.gallery.findIndex(item => item.is_main);
      setCurrentGalleryIndex(mainIndex >= 0 ? mainIndex : 0);
    } else {
      setCurrentGalleryIndex(0);
    }
  }, [selectedProject]);

  const loadProjects = async () => {
    try {
      const data = await getPublishedProjects();
      setProjects(data);
    } catch (error) {
      console.error('프로젝트 로드 실패:', error);
    } finally {
      setLoading(false);
    }
  };

  // 유튜브 ID 추출
  const getYoutubeId = (url: string) => {
    return url.match(/(?:youtube\.com\/watch\?v=|youtu\.be\/)([^&?]+)/)?.[1];
  };

  // 대표 프로젝트
  const featuredProjects = projects.filter(p => p.is_featured);

  // 년도별 그룹핑 (최신순)
  const projectsByYear = projects.reduce((acc, project) => {
    const year = project.date_start?.split('/')[0] || '기타';
    if (!acc[year]) acc[year] = [];
    acc[year].push(project);
    return acc;
  }, {} as Record<string, Project[]>);

  const sortedYears = Object.keys(projectsByYear).sort((a, b) => {
    if (a === '기타') return 1;
    if (b === '기타') return -1;
    return Number(b) - Number(a);
  });

  // 썸네일 그리드 컴포넌트
  const ThumbnailGrid = ({ items }: { items: Project[] }) => (
    <div className="grid grid-cols-6 gap-2">
      {items.map((project) => {
        const mainCategory = project.categories[0] || 'etc';
        const color = categoryColors[mainCategory] ?? categoryColors.etc;
        return (
          <div
            key={project.id}
            onClick={() => project.has_detail && setSelectedProject(project)}
            className={`relative aspect-square overflow-hidden rounded-[6px] group
              ${project.has_detail ? 'cursor-pointer' : 'cursor-default'}`}
          >
            {project.thumbnail ? (
              <img
                src={project.thumbnail}
                alt={project.title}
                className={`w-full h-full object-cover transition-transform
                  ${project.has_detail ? 'group-hover:scale-105' : ''}`}
              />
            ) : (
              <div className="w-full h-full bg-[#e5e7eb] flex items-center justify-center text-[#9ca3af] text-[11px]">
                이미지
              </div>
            )}
            
            <span className={`absolute top-2 right-2 px-2 py-0.5 text-[10px] font-medium rounded ${color?.bg || 'bg-[#6b7280]'} ${color?.text || 'text-white'}`}>
              {categoryLabels[mainCategory] || mainCategory}
            </span>

            {project.has_detail && (
              <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center p-2">
                <p className="text-white text-[12px] font-medium text-center line-clamp-2">
                  {project.title}
                </p>
              </div>
            )}
          </div>
        );
      })}
    </div>
  );

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px] text-[#9ca3af]">
        로딩 중...
      </div>
    );
  }

  // 프로젝트 선택 시 상세 표시
  if (selectedProject) {
    const gallery = selectedProject.gallery || [];
    const currentItem = gallery[currentGalleryIndex];
    const isVertical = currentItem?.type === 'ver';
    const youtubeId = (currentItem?.type === 'hor' || currentItem?.type === 'ver') ? getYoutubeId(currentItem.url) : null;

    // 세로영상 2열 레이아웃
    if (isVertical) {
      return (
        <div className="space-y-6">
          {/* 상단: 뒤로버튼 + 제목 + 카테고리 배지 */}
          <div className="flex items-center gap-4">
            <button
              onClick={() => setSelectedProject(null)}
              className="w-10 h-10 bg-black/30 backdrop-blur-sm text-white rounded-full flex items-center justify-center hover:bg-black/50 transition-all hover:scale-105 flex-shrink-0"
            >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
              </svg>
            </button>
            <h2 className="text-[21px] text-[#1f2937] flex-1 truncate" style={{ fontFamily: 'S-CoreDream', fontWeight: 900, letterSpacing: '-0.03em' }}>{selectedProject.title}</h2>
            <div className="flex gap-2 flex-shrink-0">
              {selectedProject.categories.map((cat) => {
                const color = categoryColors[cat] ?? categoryColors.etc;
                return (
                  <span key={cat} className={`px-3 py-1 text-[12px] font-medium rounded-full ${color?.bg || 'bg-[#6b7280]'} ${color?.text || 'text-white'}`}>
                    {categoryLabels[cat] || cat}
                  </span>
                );
              })}
            </div>
          </div>

          {/* 2열 레이아웃: 세로영상 + 정보 */}
          <div className="flex gap-6">
            {/* 좌측: 세로영상 */}
            <div 
              className="w-[380px] flex-shrink-0"
              onMouseEnter={() => setIsHoveringMain(true)}
              onMouseLeave={() => setIsHoveringMain(false)}
            >
              <div className="aspect-[9/16] rounded-[12px] overflow-hidden relative bg-black">
                {youtubeId ? (
                  isYoutubePlaying ? (
                    <>
                      {/* iframe을 16:9 → 9:16 비율 맞추기 위해 확대 */}
                      <div className="absolute inset-0 flex items-center justify-center">
                        <iframe
                          src={`https://www.youtube.com/embed/${youtubeId}?autoplay=1&rel=0`}
                          title={currentItem?.title || selectedProject.title}
                          className="w-[320%] h-full"
                          style={{ marginLeft: '0' }}
                          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                          allowFullScreen
                        />
                      </div>
                      <button
                        onClick={() => setIsYoutubePlaying(false)}
                        className="absolute top-4 right-4 w-10 h-10 bg-black/30 backdrop-blur-sm text-white rounded-full flex items-center justify-center hover:bg-black/50 transition-all hover:scale-105 z-10"
                      >
                        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                        </svg>
                      </button>
                    </>
                  ) : (
                    <div 
                      className="relative w-full h-full cursor-pointer group"
                      onClick={() => setIsYoutubePlaying(true)}
                    >
                      <img
                        src={`https://img.youtube.com/vi/${youtubeId}/maxresdefault.jpg`}
                        alt={currentItem?.title || selectedProject.title}
                        className="w-full h-full object-cover"
                        onError={(e) => {
                          (e.target as HTMLImageElement).src = `https://img.youtube.com/vi/${youtubeId}/hqdefault.jpg`;
                        }}
                      />
                      <div className="absolute inset-0 flex items-center justify-center">
                        <div className="w-16 h-16 bg-black/30 backdrop-blur-sm rounded-full flex items-center justify-center hover:bg-black/50 transition-all hover:scale-105">
                          <svg className="w-8 h-8 text-white ml-1" fill="currentColor" viewBox="0 0 24 24">
                            <path d="M8 5v14l11-7z"/>
                          </svg>
                        </div>
                      </div>
                    </div>
                  )
                ) : (
                  <div className="w-full h-full bg-[#f3f4f6] flex items-center justify-center text-[#9ca3af]">
                    영상 없음
                  </div>
                )}

                {/* 호버 시 갤러리 썸네일 */}
                {gallery.length > 1 && isHoveringMain && !isYoutubePlaying && (
                  <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/70 to-transparent p-4 pt-8">
                    <div className="flex gap-2 justify-center">
                      {gallery.map((item, index) => {
                        const thumbYoutubeId = (item.type === 'hor' || item.type === 'ver') ? getYoutubeId(item.url) : null;
                        return (
                          <button
                            key={index}
                            onClick={(e) => {
                              e.stopPropagation();
                              setCurrentGalleryIndex(index);
                              setIsYoutubePlaying(false);
                            }}
                            className={`w-[50px] h-[50px] rounded overflow-hidden border-2 transition-all
                              ${currentGalleryIndex === index ? 'border-white scale-105' : 'border-transparent opacity-70 hover:opacity-100'}`}
                          >
                            {thumbYoutubeId ? (
                              <img src={`https://img.youtube.com/vi/${thumbYoutubeId}/mqdefault.jpg`} alt="" className="w-full h-full object-cover" />
                            ) : (
                              <img src={item.url} alt="" className="w-full h-full object-cover" />
                            )}
                          </button>
                        );
                      })}
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* 우측: 정보 */}
            <div className="flex-1 bg-white rounded-[12px] p-6 shadow-sm">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-[14px] font-semibold text-[#6b7280] uppercase tracking-wide">Project Information</h3>
                {selectedProject.link && (
                  <a 
                    href={selectedProject.link}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-[#3071a5] hover:text-[#265d8a] transition-colors"
                  >
                    <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" />
                    </svg>
                  </a>
                )}
              </div>
              
              <div className="space-y-4">
                <div>
                  <p className="text-[12px] text-[#9ca3af] uppercase tracking-wide mb-1">Client</p>
                  <p className="text-[15px] text-[#1f2937]">{selectedProject.client || '-'}</p>
                </div>
                <div>
                  <p className="text-[12px] text-[#9ca3af] uppercase tracking-wide mb-1">Date</p>
                  <p className="text-[15px] text-[#1f2937]">
                    {selectedProject.date_start 
                      ? `${selectedProject.date_start}${selectedProject.date_end ? ` - ${selectedProject.date_end}` : ''}`
                      : '-'
                    }
                  </p>
                </div>
                {selectedProject.content && (
                  <div>
                    <p className="text-[12px] text-[#9ca3af] uppercase tracking-wide mb-1">Description</p>
                    <p className="text-[15px] text-[#374151] leading-relaxed whitespace-pre-wrap">
                      {selectedProject.content}
                    </p>
                  </div>
                )}
                {selectedProject.details && (
                  <div>
                    <p className="text-[12px] text-[#9ca3af] uppercase tracking-wide mb-1">Details</p>
                    <p className="text-[15px] text-[#374151] leading-relaxed whitespace-pre-wrap">
                      {selectedProject.details}
                    </p>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      );
    }

    // 일반 가로영상/이미지 레이아웃
    return (
      <div className="space-y-6">
        {/* 상단: 뒤로버튼 + 제목 + 카테고리 배지 */}
        <div className="flex items-center gap-4">
          <button
            onClick={() => setSelectedProject(null)}
            className="w-10 h-10 bg-black/30 backdrop-blur-sm text-white rounded-full flex items-center justify-center hover:bg-black/50 transition-all hover:scale-105 flex-shrink-0"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
            </svg>
          </button>
          <h2 className="text-[21px] text-[#1f2937] flex-1 truncate" style={{ fontFamily: 'S-CoreDream', fontWeight: 900, letterSpacing: '-0.03em' }}>{selectedProject.title}</h2>
          <div className="flex gap-2 flex-shrink-0">
            {selectedProject.categories.map((cat) => {
              const color = categoryColors[cat] ?? categoryColors.etc;
              return (
                <span key={cat} className={`px-3 py-1 text-[12px] font-medium rounded-full ${color?.bg || 'bg-[#6b7280]'} ${color?.text || 'text-white'}`}>
                  {categoryLabels[cat] || cat}
                </span>
              );
            })}
          </div>
        </div>

        {/* 메인 비주얼 (16:9) */}
        {gallery.length > 0 ? (
          <div 
            className="w-full aspect-video rounded-[12px] overflow-hidden relative"
            onMouseEnter={() => setIsHoveringMain(true)}
            onMouseLeave={() => setIsHoveringMain(false)}
          >
            {(currentItem?.type === 'hor') && youtubeId ? (
              isYoutubePlaying ? (
                <>
                  <iframe
                    src={`https://www.youtube.com/embed/${youtubeId}?autoplay=1&rel=0`}
                    title={currentItem?.title || selectedProject.title}
                    className="w-full h-full"
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                    allowFullScreen
                  />
                  <button
                    onClick={() => setIsYoutubePlaying(false)}
                    className="absolute top-4 right-4 w-10 h-10 bg-black/30 backdrop-blur-sm text-white rounded-full flex items-center justify-center hover:bg-black/50 transition-all hover:scale-105"
                  >
                    <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                    </svg>
                  </button>
                </>
              ) : (
                <div 
                  className="relative w-full h-full cursor-pointer group"
                  onClick={() => setIsYoutubePlaying(true)}
                >
                  <img
                    src={`https://img.youtube.com/vi/${youtubeId}/maxresdefault.jpg`}
                    alt={currentItem?.title || selectedProject.title}
                    className="w-full h-full object-cover"
                    onError={(e) => {
                      (e.target as HTMLImageElement).src = `https://img.youtube.com/vi/${youtubeId}/hqdefault.jpg`;
                    }}
                  />
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="w-16 h-16 bg-black/30 backdrop-blur-sm rounded-full flex items-center justify-center hover:bg-black/50 transition-all hover:scale-105">
                      <svg className="w-8 h-8 text-white ml-1" fill="currentColor" viewBox="0 0 24 24">
                        <path d="M8 5v14l11-7z"/>
                      </svg>
                    </div>
                  </div>
                </div>
              )
            ) : currentItem?.type === 'img' ? (
              <img
                src={currentItem.url}
                alt={currentItem.title || selectedProject.title}
                className="w-full h-full object-cover"
              />
            ) : selectedProject.thumbnail ? (
              <img
                src={selectedProject.thumbnail}
                alt={selectedProject.title}
                className="w-full h-full object-cover"
              />
            ) : (
              <div className="w-full h-full bg-[#f3f4f6] flex items-center justify-center text-[#9ca3af]">
                이미지 없음
              </div>
            )}

            {/* 호버 시 갤러리 썸네일 */}
            {gallery.length > 1 && isHoveringMain && !isYoutubePlaying && (
              <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/70 to-transparent p-4 pt-8">
                <div className="flex gap-2 justify-center">
                  {gallery.map((item, index) => {
                    const thumbYoutubeId = (item.type === 'hor' || item.type === 'ver') ? getYoutubeId(item.url) : null;
                    return (
                      <button
                        key={index}
                        onClick={(e) => {
                          e.stopPropagation();
                          setCurrentGalleryIndex(index);
                          setIsYoutubePlaying(false);
                        }}
                        className={`w-[80px] h-[45px] rounded overflow-hidden border-2 transition-all
                          ${currentGalleryIndex === index ? 'border-white scale-105' : 'border-transparent opacity-70 hover:opacity-100'}`}
                      >
                        {thumbYoutubeId ? (
                          <img src={`https://img.youtube.com/vi/${thumbYoutubeId}/mqdefault.jpg`} alt="" className="w-full h-full object-cover" />
                        ) : (
                          <img src={item.url} alt="" className="w-full h-full object-cover" />
                        )}
                      </button>
                    );
                  })}
                </div>
              </div>
            )}
          </div>
        ) : selectedProject.thumbnail ? (
          <img
            src={selectedProject.thumbnail}
            alt={selectedProject.title}
            className="w-full aspect-video object-cover rounded-[12px]"
          />
        ) : null}

        {/* 프로젝트 인포메이션 박스 */}
        <div className="bg-white rounded-[12px] p-6 shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-[14px] font-semibold text-[#6b7280] uppercase tracking-wide">Project Information</h3>
            {selectedProject.link && (
              <a 
                href={selectedProject.link}
                target="_blank"
                rel="noopener noreferrer"
                className="text-[#3071a5] hover:text-[#265d8a] transition-colors"
              >
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" />
                </svg>
              </a>
            )}
          </div>
          
          {/* 1열 구조 */}
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-6">
              <div>
                <p className="text-[12px] text-[#9ca3af] uppercase tracking-wide mb-1">Client</p>
                <p className="text-[15px] text-[#1f2937]">{selectedProject.client || '-'}</p>
              </div>
              <div>
                <p className="text-[12px] text-[#9ca3af] uppercase tracking-wide mb-1">Date</p>
                <p className="text-[15px] text-[#1f2937]">
                  {selectedProject.date_start 
                    ? `${selectedProject.date_start}${selectedProject.date_end ? ` - ${selectedProject.date_end}` : ''}`
                    : '-'
                  }
                </p>
              </div>
            </div>
            {selectedProject.content && (
              <div>
                <p className="text-[12px] text-[#9ca3af] uppercase tracking-wide mb-1">Description</p>
                <p className="text-[15px] text-[#374151] leading-relaxed whitespace-pre-wrap">
                  {selectedProject.content}
                </p>
              </div>
            )}
            {selectedProject.details && (
              <div>
                <p className="text-[12px] text-[#9ca3af] uppercase tracking-wide mb-1">Details</p>
                <p className="text-[15px] text-[#374151] leading-relaxed whitespace-pre-wrap">
                  {selectedProject.details}
                </p>
              </div>
            )}
          </div>
        </div>
      </div>
    );
  }

  // 목록 표시
  // 전체 프로젝트 (최신순) - 대표 프로젝트도 포함
  const allProjects = [...projects].sort((a, b) => {
    const dateA = a.date_start || '0000';
    const dateB = b.date_start || '0000';
    return dateB.localeCompare(dateA);
  });

  return (
    <div className="space-y-[30px]">
      {/* Featured - 카드만 (헤더 박스 없음) */}
      {featuredProjects.length > 0 && (
        <div className="space-y-4">
          {featuredProjects.slice(0, 3).map((project) => {
            // 갤러리에서 메인 영상/이미지 찾기
            const mainGalleryItem = project.gallery?.find(item => item.is_main) || project.gallery?.[0];
            const youtubeId = mainGalleryItem && (mainGalleryItem.type === 'hor' || mainGalleryItem.type === 'ver') 
              ? getYoutubeId(mainGalleryItem.url) 
              : null;
            const thumbnailUrl = youtubeId 
              ? `https://img.youtube.com/vi/${youtubeId}/maxresdefault.jpg`
              : project.thumbnail;

            return (
              <div
                key={project.id}
                onClick={() => project.has_detail && setSelectedProject(project)}
                className={`flex gap-5 p-4 bg-white rounded-[12px] border border-[#e5e7eb] transition-all
                  ${project.has_detail ? 'cursor-pointer hover:bg-[#f9fafb] hover:border-[#3071a5]' : 'cursor-default'}`}
              >
                {/* 좌측: 썸네일 16:9 + 배지 오버레이 */}
                <div className="w-[280px] flex-shrink-0 relative">
                  <div className="aspect-video overflow-hidden bg-[#f3f4f6]">
                    {thumbnailUrl ? (
                      <img
                        src={thumbnailUrl}
                        alt={project.title}
                        className="w-full h-full object-cover"
                        onError={(e) => {
                          if (youtubeId) {
                            (e.target as HTMLImageElement).src = `https://img.youtube.com/vi/${youtubeId}/hqdefault.jpg`;
                          }
                        }}
                      />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center text-[#9ca3af] text-[12px]">
                        이미지
                      </div>
                    )}
                    {/* 유튜브 재생 아이콘 */}
                    {youtubeId && (
                      <div className="absolute inset-0 flex items-center justify-center">
                        <div className="w-10 h-10 bg-black/40 rounded-full flex items-center justify-center">
                          <svg className="w-5 h-5 text-white ml-0.5" fill="currentColor" viewBox="0 0 24 24">
                            <path d="M8 5v14l11-7z"/>
                          </svg>
                        </div>
                      </div>
                    )}
                  </div>
                  {/* 카테고리 배지 - 썸네일 우측 상단 */}
                  <div className="absolute top-2 right-2 flex gap-1">
                    {project.categories.map((cat) => {
                      const color = categoryColors[cat] ?? categoryColors.etc;
                      return (
                        <span key={cat} className={`px-2 py-0.5 text-[10px] font-medium rounded ${color?.bg || 'bg-[#6b7280]'} ${color?.text || 'text-white'}`}>
                          {categoryLabels[cat] || cat}
                        </span>
                      );
                    })}
                  </div>
                </div>
                {/* 구분선 */}
                <div className="w-px bg-[#e5e7eb] self-stretch" />
                {/* 우측: 상세정보 */}
                <div className="flex-1 min-w-0 flex flex-col justify-center">
                  {/* 제목 */}
                  <h3 className="text-[18px] font-bold text-[#1f2937] mb-1 truncate">{project.title}</h3>
                  {/* 클라이언트 | 날짜 */}
                  <p className="text-[13px] text-[#9ca3af] mb-2">
                    {project.client && <span>{project.client}</span>}
                    {project.client && project.date_start && <span> | </span>}
                    {project.date_start && (
                      <span>{project.date_start}{project.date_end && ` - ${project.date_end}`}</span>
                    )}
                  </p>
                  {/* 설명 */}
                  {project.description && (
                    <p className="text-[14px] text-[#6b7280] line-clamp-2 mb-2">{project.description}</p>
                  )}
                  {/* 디테일 */}
                  {project.details && (
                    <p className="text-[13px] text-[#9ca3af] line-clamp-1 mb-2">{project.details}</p>
                  )}
                  {/* 태그 */}
                  {project.tags && project.tags.length > 0 && (
                    <div className="flex gap-1.5 flex-wrap">
                      {project.tags.slice(0, 5).map((tag) => (
                        <span key={tag} className="text-[12px] text-[#6b7280] bg-[#f3f4f6] px-2 py-0.5 rounded">
                          #{tag}
                        </span>
                      ))}
                      {project.tags.length > 5 && (
                        <span className="text-[12px] text-[#9ca3af]">+{project.tags.length - 5}</span>
                      )}
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* All Projects - 리스트 테이블 (헤더 없음, 대표도 포함) */}
      {allProjects.length > 0 && (
        <div className="bg-white rounded-[12px] border border-[#e5e7eb] overflow-hidden">
          <div className="divide-y divide-[#e5e7eb]">
            {allProjects.map((project) => (
              <div
                key={project.id}
                onClick={() => project.has_detail && setSelectedProject(project)}
                className={`flex items-center px-4 py-3 transition-all
                  ${project.has_detail ? 'cursor-pointer hover:bg-[#f9fafb]' : 'cursor-default'}`}
              >
                {/* 제작일 */}
                <div className="w-[80px] flex-shrink-0 text-[13px] text-[#9ca3af]">
                  {project.date_start || '-'}
                </div>
                {/* 프로젝트명 */}
                <div className="w-[200px] flex-shrink-0 text-[14px] font-medium text-[#1f2937] truncate">
                  {project.title}
                </div>
                {/* 클라이언트 */}
                <div className="w-[120px] flex-shrink-0 text-[13px] text-[#6b7280] truncate">
                  {project.client || '-'}
                </div>
                {/* 내용 */}
                <div className="flex-1 min-w-0 text-[13px] text-[#6b7280] truncate pr-4">
                  {project.description || '-'}
                </div>
                {/* 카테고리 */}
                <div className="flex-shrink-0 flex gap-1">
                  {project.categories.map((cat) => {
                    const color = categoryColors[cat] ?? categoryColors.etc;
                    return (
                      <span key={cat} className={`px-2 py-0.5 text-[10px] font-medium rounded ${color?.bg || 'bg-[#6b7280]'} ${color?.text || 'text-white'}`}>
                        {categoryLabels[cat] || cat}
                      </span>
                    );
                  })}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
