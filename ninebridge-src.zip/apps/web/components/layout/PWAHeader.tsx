'use client';

import React from 'react';

export default function PWAHeader() {
  return (
    <header className="bg-[#3071a5] text-white px-4 py-3 flex items-center justify-between sticky top-0 z-50">
      {/* 로고 */}
      <div className="flex items-center gap-2">
        <span className="text-xl font-bold tracking-tight">NINE BRIDGE</span>
      </div>
      
      {/* 우측 여백 또는 아이콘 */}
      <div className="w-8" />
    </header>
  );
}
