'use client';

import React from 'react';
import { Home, Code, Calendar, Megaphone, Camera, Mail } from 'lucide-react';

interface PWANavBarProps {
  onMenuSelect?: (menu: string) => void;
  activeMenu?: string;
}

export default function PWANavBar({ onMenuSelect, activeMenu = 'home' }: PWANavBarProps) {
  const navItems = [
    { id: 'home', icon: <Home size={20} />, label: '홈' },
    { id: 'development', icon: <Code size={20} />, label: '개발' },
    { id: 'event', icon: <Calendar size={20} />, label: '행사' },
    { id: 'marketing', icon: <Megaphone size={20} />, label: '마케팅' },
    { id: 'media', icon: <Camera size={20} />, label: '미디어' },
    { id: 'contact', icon: <Mail size={20} />, label: '문의' },
  ];

  const handleClick = (id: string) => {
    if (onMenuSelect) {
      onMenuSelect(id);
    }
  };

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 z-50 max-w-[430px] mx-auto">
      <div className="flex items-center justify-around py-2">
        {navItems.map((item) => (
          <button
            key={item.id}
            onClick={() => handleClick(item.id)}
            className={`flex flex-col items-center gap-0.5 px-2 py-1.5 rounded-lg transition-colors min-w-[50px]
              ${activeMenu === item.id 
                ? 'text-[#3071a5]' 
                : 'text-gray-400 hover:text-[#3071a5]'
              }`}
          >
            {item.icon}
            <span className="text-[10px]">{item.label}</span>
          </button>
        ))}
      </div>
      {/* Safe area for iOS */}
      <div className="pb-[env(safe-area-inset-bottom)]" />
    </nav>
  );
}
