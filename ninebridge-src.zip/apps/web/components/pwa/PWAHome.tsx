'use client';

import React from 'react';
import { Code, Calendar, Megaphone, Camera, ChevronRight } from 'lucide-react';

interface PWAHomeProps {
  onMenuSelect?: (menu: string) => void;
}

export default function PWAHome({ onMenuSelect }: PWAHomeProps) {
  const menuItems = [
    {
      id: 'development',
      icon: <Code className="w-6 h-6" />,
      title: '개발',
      description: '웹, 앱, PWA 기획 및 제작',
      count: 4,
      color: 'bg-blue-500',
    },
    {
      id: 'event',
      icon: <Calendar className="w-6 h-6" />,
      title: '행사기획',
      description: '축제, 공연, 이벤트, 세미나',
      count: 12,
      color: 'bg-orange-500',
    },
    {
      id: 'marketing',
      icon: <Megaphone className="w-6 h-6" />,
      title: '마케팅',
      description: 'SNS, 라이브커머스, 홍보영상',
      count: 8,
      color: 'bg-green-500',
    },
    {
      id: 'media',
      icon: <Camera className="w-6 h-6" />,
      title: '영상/사진',
      description: '촬영 및 제작 서비스',
      count: 20,
      color: 'bg-purple-500',
    },
  ];

  return (
    <div className="px-4 py-6">
      {/* 히어로 섹션 */}
      <div className="bg-gradient-to-br from-[#3071a5] to-[#1e4d6b] rounded-2xl p-6 text-white mb-6">
        <p className="text-xs tracking-widest uppercase mb-2 opacity-80">
          Connect Everything
        </p>
        <h1 className="text-2xl font-bold mb-2">
          연결을 디자인합니다
        </h1>
        <p className="text-sm opacity-90">
          웹/앱 개발, 행사기획, 마케팅, 영상제작<br />
          나인브릿지가 당신의 비즈니스를 연결합니다
        </p>
      </div>

      {/* 메뉴 리스트 */}
      <div className="space-y-3">
        <h2 className="text-sm font-semibold text-gray-500 uppercase tracking-wider px-1">
          Business Areas
        </h2>
        
        {menuItems.map((item) => (
          <button
            key={item.id}
            onClick={() => onMenuSelect?.(item.id)}
            className="w-full flex items-center gap-4 p-4 bg-gray-50 rounded-xl hover:bg-gray-100 transition-colors text-left"
          >
            <div className={`w-12 h-12 ${item.color} rounded-xl flex items-center justify-center text-white`}>
              {item.icon}
            </div>
            <div className="flex-1">
              <div className="flex items-center justify-between">
                <h3 className="font-semibold text-gray-800">{item.title}</h3>
                <span className="text-xs text-gray-400">{item.count}건</span>
              </div>
              <p className="text-sm text-gray-500">{item.description}</p>
            </div>
            <ChevronRight className="w-5 h-5 text-gray-300" />
          </button>
        ))}
      </div>

      {/* 회사 정보 */}
      <div className="mt-8 pt-6 border-t border-gray-100">
        <div className="text-center text-sm text-gray-500">
          <p className="font-medium text-gray-700 mb-1">주식회사 나인브릿지</p>
          <p>강원특별자치도 강릉시 하슬라로206번길 23-13</p>
          <p>033-823-0133 | rev_nine@naver.com</p>
        </div>
      </div>
    </div>
  );
}
